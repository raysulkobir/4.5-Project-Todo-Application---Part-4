<?php

namespace App\Http\Controllers;

use App\Models\Todo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $result =  Todo::all();

        $todos = [];
        foreach($result as $todo){
            $todo = [
                'id' => $todo->id,
                'text' => $todo->text,
                'completed' => $todo->completed ? true : false,
                'color' => $todo->color,
            ];

            array_push($todos, $todo);
        }
        return $todos;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'text'   => 'required|unique:todos,text',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $todo = new Todo;
        $todo->text = $request->text;
        $todo->completed = $request->completed;
        $todo->color = $request->color;


        if ($todo->save()) {
            return $todo;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Todo  $todo
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Todo::find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Todo  $todo
     * @return \Illuminate\Http\Response
     */
    public function edit(Todo $todo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Todo  $todo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //    return $request->all();
        $todo = Todo::find($id);

        if (isset($request->color)) {
            $todo->color = $request->color;
        } elseif (isset($request->completed)) {
            if ($todo->completed) {
                $todo->completed = 0;
            } else {
                $todo->completed = 1;
            }
        }
        if ($todo->update()) {
            return response()->json($todo, 200);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Todo  $todo
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            Todo::find($id)->delete();
            return ['status' => 200, 'massage' => 'delete success'];
        } catch (\Throwable $th) {
            //throw $th;
        }
    }
}
